package ZanwarTech.minor2.team3.HungryChunks.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.List;

import ZanwarTech.minor2.team3.HungryChunks.Classes.Order;
import ZanwarTech.minor2.team3.HungryChunks.R;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {
    Context contextOrder;
    List<Order> orderList;

    public OrderAdapter(Context contextOrder, List<Order> orderList) {
        this.contextOrder = contextOrder;
        this.orderList = orderList;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.rcv_order_history,parent,false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {

        holder.orderID.setText("OrderID="+orderList.get(position).getOrderID());
        holder.productID.setText("ProductId="+orderList.get(position).getProductID());
        holder.customerID.setText("CustomerID="+orderList.get(position).getCustomerID());
        holder.orderDate.setText("Date="+orderList.get(position).getOrderDate());
        holder.orderQuantity.setText("Quantity="+orderList.get(position).getOrderQuantity());


    }
    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView orderID,productID,customerID,orderDate,orderQuantity;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);

            orderID=itemView.findViewById(R.id.txtOhOrderId);
            productID=itemView.findViewById(R.id.txtOhProductID);
            customerID=itemView.findViewById(R.id.txtOhCustomerId);
            orderDate=itemView.findViewById(R.id.txtOhDate);
            orderQuantity=itemView.findViewById(R.id.txtOhQuantity);
        }
    }
}
