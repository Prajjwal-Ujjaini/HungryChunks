package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.WrapperListAdapter;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ZanwarTech.minor2.team3.HungryChunks.Adapters.OrderAdapter;
import ZanwarTech.minor2.team3.HungryChunks.Classes.Order;
import ZanwarTech.minor2.team3.HungryChunks.Interfaces.Web_Url;

public class MyOrders extends AppCompatActivity implements Web_Url {

    RecyclerView recyclerViewMyOrder;
    List<Order> orderListMyOrder;
    OrderAdapter orderAdapterMyOrder;
    ProgressBar pbMyO;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String CustomerID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_orders);
        getSupportActionBar().setTitle("MY ORDERS");


        pbMyO=findViewById(R.id.pbMyO);
        recyclerViewMyOrder=findViewById(R.id.rcvMyOrder);

        sharedPreferences=getSharedPreferences("SP",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        CustomerID=sharedPreferences.getString("CustomerId","DEFAULT CustomerId");

        recyclerViewMyOrder.addItemDecoration(new DividerItemDecoration(getApplicationContext(),DividerItemDecoration.VERTICAL));
        recyclerViewMyOrder.setHasFixedSize(true);
        recyclerViewMyOrder.setLayoutManager(new LinearLayoutManager(this));

        orderListMyOrder=new ArrayList<>();

        getMyOrderFromServer();
    }

    private void getMyOrderFromServer() {
        pbMyO.setVisibility(View.VISIBLE);

        final Map map=new HashMap();
        map.put("c_id",CustomerID);
        RequestQueue requestQueueMyOrder= Volley.newRequestQueue(this);
        StringRequest stringRequestMyOrder=new StringRequest(Request.Method.POST,Url+"see_Perticular_person_Order.php" , new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
             //   Toast.makeText(MyOrders.this, response, Toast.LENGTH_SHORT).show();

                try {
                    JSONObject jsonObjectMyOrder=new JSONObject(response);
                    JSONArray jsonArrayMyOrder=jsonObjectMyOrder.getJSONArray("students");
                    pbMyO.setVisibility(View.GONE);
                    for (int i=0;i<jsonArrayMyOrder.length();i++){
                        JSONObject tmpMyOrder=jsonArrayMyOrder.getJSONObject(i);

                        Order itemMyOrderList=new Order(tmpMyOrder.getString("o_id"),tmpMyOrder.getString("p_id"),
                                tmpMyOrder.getString("c_id"),tmpMyOrder.getString("o_date"),
                                tmpMyOrder.getString("o_quantity"));
                        orderListMyOrder.add(itemMyOrderList);
                    }
                    orderAdapterMyOrder =new OrderAdapter(getApplicationContext(),orderListMyOrder);
                    recyclerViewMyOrder.setAdapter(orderAdapterMyOrder);
                } catch (JSONException e) {
                    pbMyO.setVisibility(View.GONE);
                    e.printStackTrace();
                    Toast.makeText(MyOrders.this, "catch error=="+e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pbMyO.setVisibility(View.GONE);
                Toast.makeText(MyOrders.this, "error in response ==="+error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return map;
            }
        };
        requestQueueMyOrder.add(stringRequestMyOrder);
    }
}
