package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import ZanwarTech.minor2.team3.HungryChunks.Classes.CustomerDetails;
import ZanwarTech.minor2.team3.HungryChunks.Interfaces.Web_Url;

public class LoginCustomer extends AppCompatActivity implements Web_Url {
    private EditText etLMno,etLPwd;
    private String strLoginCMno,strLoginCPwd;

    ProgressBar pbL;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_customer);
        getSupportActionBar().setTitle("Login");

        findid();
    }
    public void findid(){
        etLMno=findViewById(R.id.etLoginMno);
        etLPwd=findViewById(R.id.etLoginPwd);
        pbL=findViewById(R.id.pbL);
    }
    /* public void gotoWl(View view){
         Intent intent=new Intent(this,Welcome.class);
         startActivity(intent);
     }

     */
    public void gotoFP(View view){
        Intent intent=new Intent(this,ForgotPassword.class);
        startActivity(intent);
    }


    public void login(View view){
        strLoginCMno=etLMno.getText().toString().trim();
        strLoginCPwd=etLPwd.getText().toString().trim();

        if (strLoginCMno.length() < 10) {
            Toast.makeText(getApplicationContext(), "Please Enter 10 digit mobile number", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!TextUtils.isEmpty(strLoginCMno) && !TextUtils.isEmpty(strLoginCPwd)){
            pbL.setVisibility(View.VISIBLE);

            final Map map = new HashMap();
            map.put("cstmr_mno",strLoginCMno);
            map.put("cstmr_pwd", strLoginCPwd);

            try{
                RequestQueue queue= Volley.newRequestQueue(this);
                StringRequest request=new StringRequest(Request.Method.POST, Url + "login_costumer.php", new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Log.e("response:", response);
                        //Toast.makeText(getApplicationContext(), "response:" + response, Toast.LENGTH_SHORT).show();
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            String data=jsonObject.getString("success");

                            if(data.equals("1")){
                                Toast.makeText(getApplicationContext(), "logged in", Toast.LENGTH_SHORT).show();

                                //Toast.makeText(LoginCustomer.this, "TERRRRRRR="+jsonObject, Toast.LENGTH_LONG).show();

                                Intent intent=new Intent(LoginCustomer.this,CustomerDashboard.class);

                                CustomerDetails customerDetails;
                                customerDetails=new CustomerDetails();
                                customerDetails.setCid(jsonObject.getString("c_id"));
                                customerDetails.setCstmr_name(jsonObject.getString("cstmr_name"));
                                customerDetails.setCstmr_mno(jsonObject.getString("cstmr_mno"));


                                //Intent intent=new Intent(Login_in.this,Customer_Profile.class);//working
                                //startActivity(intent);//working
                                //Toast.makeText(LoginCustomer.this,"customerdetail="+customerDetails.getCstmr_mno() , Toast.LENGTH_SHORT).show();

                                try{
                                    SharedPreferences spLogin=getSharedPreferences("SP",MODE_PRIVATE);
                                    SharedPreferences.Editor editorLogin=spLogin.edit();
                                    editorLogin.putString("CustomerId",customerDetails.getCid());
                                    editorLogin.putString("CustomerName",customerDetails.getCstmr_name());
                                    editorLogin.putString("CustomerMno",customerDetails.getCstmr_mno());
                                    //Toast.makeText(LoginCustomer.this, "tty=="+editorLogin.putString("CustomerName",customerDetails.getCstmr_name()).toString(), Toast.LENGTH_SHORT).show();
                                    editorLogin.apply();
                                }catch (Exception e){
                                    Toast.makeText(LoginCustomer.this, "catch in shared=="+e.toString(), Toast.LENGTH_SHORT).show();
                                }


                                 //intent.putExtra("ciid",customerDetails.getCid());
                                  //intent.putExtra("nam",customerDetails.getCstmr_name());
                                //intent.putExtra("cmmno",customerDetails.getCstmr_mno());

                                pbL.setVisibility(View.GONE);
                                startActivity(intent);


/*  this works when i make variables then put into intent
                            String na,cii,cmno;

                            na=jsonObject.getString("cstmr_name");
                            cii=jsonObject.getString("cid");
                            cmno=jsonObject.getString("cstmr_mno");

                            Toast.makeText(Login_in.this, cii, Toast.LENGTH_SHORT).show();
                            Toast.makeText(Login_in.this, na, Toast.LENGTH_SHORT).show();
                            Toast.makeText(Login_in.this, cmno, Toast.LENGTH_SHORT).show();

                            intent.putExtra("nam",na);
                            intent.putExtra("ciid",cii);
                            intent.putExtra("cmmno",cmno);
                            startActivity(intent);

*/

/*
                            try{
                                Toast.makeText(Login_in.this, "Intent try box", Toast.LENGTH_SHORT).show();
                                //Intent intent=new Intent(Login_in.this,Customer_Profile.class);

                                CustomerDetails details;
                                details=new CustomerDetails();

                                Toast.makeText(Login_in.this, jsonObject.getString("cid"), Toast.LENGTH_SHORT).show();//work by this line

                                details.setCstmr_name(jsonObject.getString("cstmr_name"));
                                Toast.makeText(Login_in.this, details.getCstmr_name(), Toast.LENGTH_SHORT).show();  //not print by this line

                                details.setCid(jsonObject.getString("cstmr_cid"));
                                details.setCstmr_mno(jsonObject.getString("cstmr_mno"));

                                String c,n,m;

                                c=details.getCid();
                                n=details.getCstmr_name();
                                m=details.getCstmr_mno();
                                Toast.makeText(Login_in.this,c, Toast.LENGTH_SHORT).show();
                                Toast.makeText(Login_in.this,n, Toast.LENGTH_SHORT).show();
                                Toast.makeText(Login_in.this,m, Toast.LENGTH_SHORT).show();

                                intent.putExtra("info_cstmr_cid",details.getCid());
                                intent.putExtra("info_cstmr_name",details.getCstmr_name());
                                intent.putExtra("info_cstmr_mno",details.getCstmr_mno());
                                startActivity(intent);

                            }catch (Exception ee){
                                Log.e("catch error:", ee.toString());
                                ee.printStackTrace();
                            }
*/

                           /*
                            n=details.getName();
                            g=details.getGender();
                            c=details.getCity();
                            s=details.getSid();
                            Toast.makeText(Login.this,n, Toast.LENGTH_SHORT).show();
                            Toast.makeText(Login.this,g, Toast.LENGTH_SHORT).show();
                            Toast.makeText(Login.this,c, Toast.LENGTH_SHORT).show();
                            Toast.makeText(Login.this,s, Toast.LENGTH_SHORT).show();

                            tvmno.setText(details.getMno());
                            tvname.setText(details.getName());

                            */
                            }else{
                                pbL.setVisibility(View.GONE);
                                Toast.makeText(getApplicationContext(), " Please provide correct Moblie Number or Password", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Log.e("catch error:", e.toString());
                            pbL.setVisibility(View.GONE);
                            e.printStackTrace();
                            Toast.makeText(LoginCustomer.this, "(*&^==="+e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error", error.toString());
                        pbL.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        return map;
                    }
                };
                queue.add(request);
            }catch (Exception e){
                pbL.setVisibility(View.GONE);
                Log.e("e:",e.toString());
                Toast.makeText(this, "$$=="+e.toString(), Toast.LENGTH_SHORT).show();
            }

            etLMno.setText("");
            etLPwd.setText("");
        } else {
            pbL.setVisibility(View.GONE);
            Toast.makeText(this, "Please enter data first", Toast.LENGTH_SHORT).show();
        }
    }
}
