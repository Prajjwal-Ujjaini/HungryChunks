package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ZanwarTech.minor2.team3.HungryChunks.Adapters.OrderNowAdapter;
import ZanwarTech.minor2.team3.HungryChunks.Adapters.PaymentAdapter;
import ZanwarTech.minor2.team3.HungryChunks.Classes.Payment;
import ZanwarTech.minor2.team3.HungryChunks.Classes.Product;
import ZanwarTech.minor2.team3.HungryChunks.Interfaces.Web_Url;

public class PaymentHistory extends AppCompatActivity implements Web_Url {

    RecyclerView recyclerViewPaymentHistory;
    List<Payment> paymentListPaymentHistory;
    PaymentAdapter paymentAdapterPaymentHistory;
    ProgressBar pbPyH;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String CustomerID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_history);
        getSupportActionBar().setTitle("Payment History");

        pbPyH=findViewById(R.id.pbPyH);

        sharedPreferences=getSharedPreferences("SP",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        CustomerID=sharedPreferences.getString("CustomerId","DEFAULT CustomerId");


        recyclerViewPaymentHistory=findViewById(R.id.rcvPaymentHistory);
        recyclerViewPaymentHistory.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewPaymentHistory.setHasFixedSize(true);
        recyclerViewPaymentHistory.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));

        paymentListPaymentHistory=new ArrayList<>();

        getPaymentHistoryFromServer();
    }

    private void getPaymentHistoryFromServer() {
        pbPyH.setVisibility(View.VISIBLE);

        final Map map=new HashMap();
        map.put("c_id",CustomerID);

        RequestQueue requestQueuePaymentHistory = Volley.newRequestQueue(this);
        StringRequest stringRequestPaymentHistory=new StringRequest(Request.Method.POST, Url + "see_Perticular_person_Payment.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObjectPaymentHistory =new JSONObject(response);
                    JSONArray jsonArrayOrderNow =jsonObjectPaymentHistory.getJSONArray("students");

                    pbPyH.setVisibility(View.GONE);
                    for (int i=0;i<jsonArrayOrderNow.length();i++){
                        JSONObject tmpPyH=jsonArrayOrderNow.getJSONObject(i);
                        Payment itemPaymentHistory=new Payment(tmpPyH.getString("py_id"),tmpPyH.getString("o_id"),tmpPyH.getString("c_id"),tmpPyH.getString("py_mode"),tmpPyH.getString("paid_amount"));
                        paymentListPaymentHistory.add(itemPaymentHistory);
                    }
                    paymentAdapterPaymentHistory=new PaymentAdapter(getApplicationContext(),paymentListPaymentHistory );

                    recyclerViewPaymentHistory.setAdapter(paymentAdapterPaymentHistory);

                } catch (JSONException e) {
                    pbPyH.setVisibility(View.GONE);
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "catch in fun=="+e.toString(), Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pbPyH.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "response listner=="+error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return map;
            }
        };
        requestQueuePaymentHistory.add(stringRequestPaymentHistory);

    }
}
