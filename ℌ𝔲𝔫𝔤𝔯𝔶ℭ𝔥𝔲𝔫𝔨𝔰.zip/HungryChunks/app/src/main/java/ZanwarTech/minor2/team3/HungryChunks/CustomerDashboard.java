package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class CustomerDashboard extends AppCompatActivity {
    TextView tvname;
    String str_cstmr_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_dashboard);
        getSupportActionBar().setTitle("DashBoard");

        CDId();
    }
    public void CDId(){
        tvname=findViewById(R.id.tvCDName);
       // str_cstmr_name=getIntent().getStringExtra("nam");
       try {
            SharedPreferences spCustomerDashboard=getSharedPreferences("SP", MODE_PRIVATE);

            str_cstmr_name=spCustomerDashboard.getString("CustomerName","DEFAULT");

            //Toast.makeText(this, "sharP==namr==="+str_cstmr_name, Toast.LENGTH_SHORT).show();
           //Toast.makeText(this, "direct=="+spCustomerDashboard.getString("CustomerName",""), Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(this, "catch in get shared ="+e.toString(), Toast.LENGTH_SHORT).show();
        }

        tvname.setText(str_cstmr_name);
    }

    public void clickToastPr(View view){
        Toast.makeText(this, "working ", Toast.LENGTH_SHORT).show();
    }
    public void gotoOn(View view){
        Intent intent=new Intent(this,OrderNow.class);
        startActivity(intent);
    }
    public void gotoMO(View view){
        Intent intent=new Intent(this,MyOrders.class);
        startActivity(intent);
    }
    public void gotoP(View view){
        Intent intent=new Intent(this, PaymentPage.class);
        startActivity(intent);
    }

    public void gotoPyHis(View view){
        Intent intent=new Intent(this,PaymentHistory.class);
        startActivity(intent);
    }
    public void LOGOUT(View view){
        Intent intent=new Intent(this,LoginCustomer.class);
        startActivity(intent);
    }

    public void gotoAboutus(View view){
        Intent intent=new Intent(this,AboutUs.class);
        startActivity(intent);
    }

}
