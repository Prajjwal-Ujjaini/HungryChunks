package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ZanwarTech.minor2.team3.HungryChunks.Classes.Order;
import ZanwarTech.minor2.team3.HungryChunks.Classes.Product;
import ZanwarTech.minor2.team3.HungryChunks.Interfaces.Web_Url;

public class PaymentPage extends AppCompatActivity implements Web_Url {

    RadioGroup rgPaymentOption;
    RadioButton rbPO;
//    Button btnDisplay;

    SharedPreferences sharedPreferences;
    String OrderId,CustomerID,paymentMode,paidAmount;
    ProgressBar pbPyP;
    Button btnPaymDone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_page);
        getSupportActionBar().setTitle("Final Payment");

        rgPaymentOption= (RadioGroup) findViewById(R.id.rgPaymentOption);
        pbPyP=findViewById(R.id.pbPyP);
        btnPaymDone=findViewById(R.id.btnPaymDone);
       // btnDisplay = (Button) findViewById(R.id.btnDisplay);

        sharedPreferences=getSharedPreferences("SP",MODE_PRIVATE);
        CustomerID=sharedPreferences.getString("CustomerId","DEFAULT CustomerId");
        paidAmount=sharedPreferences.getString("FinalTotalAmount","DEFAULT Final Total Amount" );

 //       Toast.makeText(this, "paid anount="+paidAmount, Toast.LENGTH_SHORT).show();

     /*   btnDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int slectID=rgPaymentOption.getCheckedRadioButtonId();
                rbPO=findViewById(slectID);
               // paymentMode=rbPO.getText().toString();
                Toast.makeText(PaymentPage.this, rbPO.getText(), Toast.LENGTH_SHORT).show();

            }
        });
      */

        btnPaymDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int slectID=rgPaymentOption.getCheckedRadioButtonId();
                //Toast.makeText(PaymentPage.this, "selectID=="+slectID, Toast.LENGTH_SHORT).show();

                rbPO=findViewById(slectID);
                try{
                    paymentMode=rbPO.getText().toString();
                }catch (Exception e){
                    Toast.makeText(PaymentPage.this, "please check the way of pament!!=="+e.toString(), Toast.LENGTH_SHORT).show();
                }
                uploadPayment();

            }
        });

    }

    public void uploadPayment(){
        pbPyP.setVisibility(View.VISIBLE);
        OrderId="0000";
        final Map map=new HashMap();
        map.put("o_id",OrderId);
        map.put("c_id",CustomerID);
        map.put("py_mode",paymentMode);
        map.put("paid_amount",paidAmount);

        RequestQueue requestQueuePaymentPage = Volley.newRequestQueue(this);
        StringRequest stringRequestPaymentPage=new StringRequest(Request.Method.POST, Url+"upload_Payment.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
               // Toast.makeText(PaymentPage.this, response, Toast.LENGTH_SHORT).show();
                try {
                    JSONObject jsonObjectPaymentPage=new JSONObject(response);
                 //   Toast.makeText(PaymentPage.this, jsonObjectPaymentPage.toString(), Toast.LENGTH_SHORT).show();
                    String data=jsonObjectPaymentPage.getString("success");
                   // Toast.makeText(PaymentPage.this, "data=="+data, Toast.LENGTH_SHORT).show();

                    if(data.equals("1")){
                        Toast.makeText(getApplicationContext(), "Payment Done", Toast.LENGTH_SHORT).show();
                        pbPyP.setVisibility(View.GONE);
                        Intent intent=new Intent(getApplicationContext(),CustomerDashboard.class);
                        startActivity(intent);
                    }else {
                        pbPyP.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(), "Payment not DONE", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    Log.e("catch error:", e.toString());
                    pbPyP.setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(), "catch run ==="+ e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("error", error.toString());
                pbPyP.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), " error listnor run  on Payment page:==="+ error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return map;
            }
        };
        requestQueuePaymentPage.add(stringRequestPaymentPage);

    }



    public void gotoDone(View view) {
        Intent intent = new Intent(this, CustomerDashboard.class);
        startActivity(intent);
    }

}
