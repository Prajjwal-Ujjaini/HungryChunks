package ZanwarTech.minor2.team3.HungryChunks.Classes;

import java.io.Serializable;

public class Product implements Serializable {
    private String productID,productName,productPrice,productQuantity,amountToPay,tmpOrderQuantity;

    public Product(String productID, String productName, String productPrice, String productQuantity) {
        this.productID = productID;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQuantity = productQuantity;
    }

    public Product(String productID, String productName, String productPrice, String amountToPay, String tmpOrderQuantity) {
        this.productID = productID;
        this.productName = productName;
        this.productPrice = productPrice;
        this.amountToPay = amountToPay;
        this.tmpOrderQuantity = tmpOrderQuantity;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(String productQuantity) {
        this.productQuantity = productQuantity;
    }

    public String getAmountToPay() {
        return amountToPay;
    }

    public void setAmountToPay(String amountToPay) {
        this.amountToPay = amountToPay;
    }

    public String getTmpOrderQuantity() {
        return tmpOrderQuantity;
    }

    public void setTmpOrderQuantity(String tmpOrderQuantity) {
        this.tmpOrderQuantity = tmpOrderQuantity;
    }
}
