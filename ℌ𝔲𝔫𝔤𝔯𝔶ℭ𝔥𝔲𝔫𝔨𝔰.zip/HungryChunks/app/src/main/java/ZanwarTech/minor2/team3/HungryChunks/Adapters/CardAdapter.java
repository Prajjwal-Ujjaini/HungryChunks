package ZanwarTech.minor2.team3.HungryChunks.Adapters;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import ZanwarTech.minor2.team3.HungryChunks.Classes.Product;
import ZanwarTech.minor2.team3.HungryChunks.R;

public class CardAdapter extends RecyclerView.Adapter<CardAdapter.CardViewHolder> {

    Context contextCard;
    List<Product> listItemCard;

    static public List<Product> amountAddedList;

    String price;
    static String countQuantity,tmpAmount;
    int tmpPrice ,tmpCount ,intAmount;


    public CardAdapter(Context contextCard, List<Product> listItemCard) {
        this.contextCard = contextCard;
        this.listItemCard = listItemCard;
    }
    @NonNull
    @Override
    public CardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.rcv_card_view,parent,false);
        return new CardViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final CardViewHolder holder, final int position) {

       // holder.productID.setText(listItemCard.get(position).getProductID());
        holder.productName.setText(listItemCard.get(position).getProductName());
        holder.productPrice.setText(listItemCard.get(position).getProductPrice());
        holder.productQuantity.setText(listItemCard.get(position).getProductQuantity());


        holder.elegantNumberButton.setOnValueChangeListener(new ElegantNumberButton.OnValueChangeListener() {
            @Override
            public void onValueChange(ElegantNumberButton view, int oldValue, int newValue) {
                countQuantity="1";
                countQuantity = holder.elegantNumberButton.getNumber();

                price=listItemCard.get(position).getProductPrice();

                holder.productQuantity.setText("Quantity="+countQuantity);

                tmpAmount=holder.tpf(price,countQuantity);

                holder.txtAmountToPay.setText("Amount To Pay ="+tmpAmount);


                //  Toast.makeText(contextCard, "amount to pa=="+listItemCard.get(position).getAmountToPay(), Toast.LENGTH_SHORT).show();
                // Toast.makeText(contextCard, "tmp quantity=="+listItemCard.get(position).getTmpOrderQuantity(), Toast.LENGTH_SHORT).show();
            }
        });

        holder.btnConfirmThisProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int check =22 ;
                
                listItemCard.get(position).setTmpOrderQuantity(countQuantity);
                listItemCard.get(position).setAmountToPay(tmpAmount);

              //  Toast.makeText(contextCard, "id="+ listItemCard.get(position).getProductID(), Toast.LENGTH_SHORT).show();
               // Toast.makeText(contextCard, "!!!=="+amountAddedList.contains(listItemCard.get(position).getProductID()), Toast.LENGTH_SHORT).show();

                for(int i=0;i<amountAddedList.size();i++){

                 //   Toast.makeText(contextCard, "working=="+(amountAddedList.get(i).getProductID().equals(listItemCard.get(position).getProductID())) , Toast.LENGTH_SHORT).show();

                    if (amountAddedList.get(i).getProductID().equals(listItemCard.get(position).getProductID())){

                   //     Toast.makeText(contextCard, "!!working!=="+(amountAddedList.get(i).getProductID().equals(listItemCard.get(position).getProductID())), Toast.LENGTH_SHORT).show();

                        amountAddedList.remove(amountAddedList.get(i));
                        Product p=new Product(listItemCard.get(position).getProductID(),
                                listItemCard.get(position).getProductName(),
                                listItemCard.get(position).getProductPrice(),
                                listItemCard.get(position).getAmountToPay(),
                                listItemCard.get(position).getTmpOrderQuantity());

                        //  Toast.makeText(contextCard, "???=="+amountAddedList.contains(listItemCard.get(position)), Toast.LENGTH_SHORT).show();
                        //  Toast.makeText(contextCard, "index of old =="+amountAddedList.indexOf(listItemCard.get(position)), Toast.LENGTH_SHORT).show();
                        //  Toast.makeText(contextCard, "p=="+p.toString(), Toast.LENGTH_SHORT).show();

                        amountAddedList.add(p);
                        Toast.makeText(contextCard, "This product is added for final order", Toast.LENGTH_SHORT).show();
                        
                        check = 0;
                    }else {
                        check = 1;
                    }
                }
                
                if(check==1 || check==22){

                    //Toast.makeText(contextCard, "else run!!!!", Toast.LENGTH_SHORT).show();
                    Product p=new Product(listItemCard.get(position).getProductID(),
                            listItemCard.get(position).getProductName(),
                            listItemCard.get(position).getProductPrice(),
                            listItemCard.get(position).getAmountToPay(),
                            listItemCard.get(position).getTmpOrderQuantity());

                    amountAddedList.add(p);
                    Toast.makeText(contextCard, "This product is added for final order", Toast.LENGTH_SHORT).show();


                }




                //Toast.makeText(contextCard, amountAddedList.toString(), Toast.LENGTH_SHORT).show();

                SharedPreferences sharedPreferences=contextCard.getSharedPreferences("SP",Context.MODE_PRIVATE);
                SharedPreferences.Editor editor=sharedPreferences.edit();
                Gson gson=new Gson();
                String json=gson.toJson(amountAddedList);
                editor.putString("amount_Added_List",json);
                editor.commit();

                //holder.tsa(listItemCard.get(position).getProductID(),listItemCard.get(position).getAmountToPay(),listItemCard.get(position).getTmpOrderQuantity());
            }
        });

     /*   holder.imgRemoveProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(contextCard, "working have do done", Toast.LENGTH_SHORT).show();
            }
        });
      */
       // Toast.makeText(contextCard, "price=="+price, Toast.LENGTH_SHORT).show();
    }

    @Override
    public int getItemCount() {
        return listItemCard.size();
    }

    public class CardViewHolder extends RecyclerView.ViewHolder{
        TextView productID,productName,productPrice,productQuantity,txtAmountToPay;
        LinearLayout linearLayout;
        ElegantNumberButton elegantNumberButton;
        Button btnConfirmThisProduct;
        ImageButton imgRemoveProduct;

        public CardViewHolder(@NonNull final View itemView) {
            super(itemView);

          //  productID=itemView.findViewById(R.id.txtCardId);
            productName=itemView.findViewById(R.id.txtCardName);
            productPrice=itemView.findViewById(R.id.txtCardPrice);
            productQuantity=itemView.findViewById(R.id.eleTextQuantity);
            linearLayout=itemView.findViewById(R.id.llCard);
            txtAmountToPay=itemView.findViewById(R.id.txtAmountToPay);
            btnConfirmThisProduct=itemView.findViewById(R.id.btnConfirmThisProduct);
            elegantNumberButton=itemView.findViewById(R.id.btnElegan);
            //imgRemoveProduct=itemView.findViewById(R.id.imgRemoveProduct);

            amountAddedList=new ArrayList<>();


            //Toast.makeText(itemView.getContext(), "prise inside =="+price, Toast.LENGTH_SHORT).show();

            //editor.putString("QuantityCount",countQuantity);
            //editor.putString("TotalAmount",tmpAmount);
           // editor.putString("pp_id",product_id);


        }

        public String tpf(String p, String c){
            tmpPrice=Integer.parseInt(p.trim());
            tmpCount=Integer.parseInt(c.trim());

            intAmount=0;
            intAmount= (tmpCount) * (tmpPrice)  ;

            //tmpAmount= String.valueOf(intAmount);
            return (String.valueOf(intAmount));
        }
/*
        public void tsa(String pid,String am,String qt){
            Product p=new Product(pid,am,qt);
            amountAddedList.add(p);
        }
 */
    }
}
