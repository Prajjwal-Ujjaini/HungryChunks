package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class CustomerProfile extends AppCompatActivity {
    TextView tvcid,tvname,tvmno;
    String str_cstmr_cid,str_cstmr_name,str_cstmr_mno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_profile);

        tvcid=findViewById(R.id.txt_cid);
        tvname=findViewById(R.id.txt_name);
        tvmno=findViewById(R.id.txt_mno);

        str_cstmr_cid=getIntent().getStringExtra("ciid");
        str_cstmr_name=getIntent().getStringExtra("nam");
        str_cstmr_mno=getIntent().getStringExtra("cmmno");

        // Toast.makeText(this, "customer profile==" +str_cstmr_cid, Toast.LENGTH_SHORT).show();
        //Toast.makeText(this, "customer profile=="+str_cstmr_name, Toast.LENGTH_SHORT).show();
        tvcid.setText(str_cstmr_cid);
        tvname.setText(str_cstmr_name);
        tvmno.setText(str_cstmr_mno);

/*
        tvcid.setText(getIntent().getExtras().getString("ciid"));
        tvname.setText(getIntent().getExtras().getShort("nam"));
        tvmno.setText(getIntent().getExtras().getString("cmmno"));


 */


/*
        str_cstmr_cid=getIntent().getExtras().getString("info_cstmr_cid");
        str_cstmr_name=getIntent().getExtras().getString("info_cstmr_name");
        str_cstmr_mno=getIntent().getExtras().getString("info_cstmr_mno");
*/
/*
        tvcid.setText(getIntent().getExtras().getString("info_cstmr_cid"));
        tvname.setText(getIntent().getExtras().getShort("info_cstmr_name"));
        tvmno.setText(getIntent().getExtras().getString("info_cstmr_mno"));
 */
    }
}
