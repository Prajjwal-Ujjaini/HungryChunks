package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;

public class MainActivity extends AppCompatActivity {
    ImageView imgMain;
    Animation shaking,rotation;
    int tmp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tmp=200;
        imgMain=findViewById(R.id.imgMain);
        shaking=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.shaking);
        rotation=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotation);

        if (tmp==200){
            imgMain.startAnimation(shaking);
            imgMain.animate().translationY(140).alpha(0).setDuration(8000).setStartDelay(300);
            imgMain.startAnimation(rotation);

            tmp=100;
        }
        if(tmp==100){
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    Intent intent=new Intent(getApplicationContext(),FrontPageChoice.class);
                    startActivity(intent);
                }
            }, 5000);

        }
    }
    public void gotoM(View view){
        Intent intent=new Intent(this,FrontPageChoice.class);
        startActivity(intent);
    }

}
