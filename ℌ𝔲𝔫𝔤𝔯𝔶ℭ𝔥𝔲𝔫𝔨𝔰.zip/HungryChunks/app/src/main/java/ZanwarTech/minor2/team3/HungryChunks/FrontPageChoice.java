package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class FrontPageChoice extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_front_page_choice);
    }
    public void gotoVrfy(View view){
        Intent intent=new Intent(this,Verification.class);
        startActivity(intent);
    }
    public void gotoCR(View view){
        Intent intent=new Intent(this,CustomerRegistration.class);
        startActivity(intent);
    }
    public void gotoL(View view){
        Intent intent=new Intent(this,LoginCustomer.class);
        startActivity(intent);
    }
}
