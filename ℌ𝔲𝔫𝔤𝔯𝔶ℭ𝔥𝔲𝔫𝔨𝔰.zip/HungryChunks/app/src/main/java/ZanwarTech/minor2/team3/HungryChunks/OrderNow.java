package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import ZanwarTech.minor2.team3.HungryChunks.Adapters.OrderNowAdapter;
import ZanwarTech.minor2.team3.HungryChunks.Classes.Product;
import ZanwarTech.minor2.team3.HungryChunks.Interfaces.Web_Url;

public class OrderNow extends AppCompatActivity implements Web_Url {

    RecyclerView recyclerViewOrderNow;
    List<Product> productListFromServer;
    OrderNowAdapter orderNowAdapter;
    ProgressBar pbON;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_now);
        getSupportActionBar().setTitle("ORDER NOW");

        pbON=findViewById(R.id.pbON);

        recyclerViewOrderNow = findViewById(R.id.rcvOrderNow);
        recyclerViewOrderNow.setHasFixedSize(true);
        recyclerViewOrderNow.setLayoutManager(new LinearLayoutManager(this));
        DividerItemDecoration dividerItemDecoration=new DividerItemDecoration(this,DividerItemDecoration.VERTICAL);
        recyclerViewOrderNow.addItemDecoration(dividerItemDecoration);

        productListFromServer=new ArrayList<>();

        /*
        for (int i=0;i<10;i++){
            Product iteamProduct=new Product(i+1+"",i+1 +" Name", i+1 +" Price " , i+1 +" Quantity");

            productListOrder.add(iteamProduct);
        }

        orderNowAdapter=new OrderNowAdapter(this,productListOrder );
        recyclerViewOrderNow.setAdapter(orderNowAdapter);

        */
        getProductListFromServer();
    }

    public void gotoCart(View view){
        Intent intent=new Intent(this, Card.class);
        startActivity(intent);
    }

    public void getProductListFromServer(){
        pbON.setVisibility(View.VISIBLE);
        RequestQueue requestQueueOrderNow = Volley.newRequestQueue(this);
        StringRequest stringRequestOrderNow=new StringRequest(Request.Method.GET, Url + "see_products.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //Toast.makeText(OrderNow.this, "response ==="+response, Toast.LENGTH_SHORT).show();
                try {
                    JSONObject jsonObjectOrderNow =new JSONObject(response);
                  //  Toast.makeText(OrderNow.this," object =="+ jsonObjectOrderNow.toString(), Toast.LENGTH_SHORT).show();

                    JSONArray jsonArrayOrderNow =jsonObjectOrderNow.getJSONArray("students");
                    //Toast.makeText(OrderNow.this, "array object=="+jsonArrayOrderNow.length(), Toast.LENGTH_SHORT).show();

                    pbON.setVisibility(View.GONE);
                    for (int i=0;i<jsonArrayOrderNow.length();i++){
                        JSONObject o=jsonArrayOrderNow.getJSONObject(i);
                        Product itemProductList=new Product(o.getString("p_id"),o.getString("p_name"),o.getString("p_price"),o.getString("p_quantity"));
                        productListFromServer.add(itemProductList);
                    }
                    orderNowAdapter=new OrderNowAdapter(getApplicationContext(),productListFromServer );

                    recyclerViewOrderNow.setAdapter(orderNowAdapter);

                } catch (JSONException e) {
                    pbON.setVisibility(View.GONE);
                    e.printStackTrace();
                    Toast.makeText(OrderNow.this, "catch in fun=="+e.toString(), Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pbON.setVisibility(View.GONE);
                Toast.makeText(OrderNow.this, "response listner=="+error.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        requestQueueOrderNow.add(stringRequestOrderNow);
    }

}
