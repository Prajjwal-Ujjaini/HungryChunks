package ZanwarTech.minor2.team3.HungryChunks.Classes;

import java.io.Serializable;

public class CustomerDetails implements Serializable {
    private String cid,cstmr_name,cstmr_mno,cstmr_pwd;

    public CustomerDetails() {
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getCstmr_name() {
        return cstmr_name;
    }

    public void setCstmr_name(String cstmr_name) {
        this.cstmr_name = cstmr_name;
    }

    public String getCstmr_mno() {
        return cstmr_mno;
    }

    public void setCstmr_mno(String cstmr_mno) {
        this.cstmr_mno = cstmr_mno;
    }

    public String getCstmr_pwd() {
        return cstmr_pwd;
    }

    public void setCstmr_pwd(String cstmr_pwd) {
        this.cstmr_pwd = cstmr_pwd;
    }
}
