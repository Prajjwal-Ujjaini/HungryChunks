package ZanwarTech.minor2.team3.HungryChunks.Adapters;


import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import ZanwarTech.minor2.team3.HungryChunks.Classes.Product;
import ZanwarTech.minor2.team3.HungryChunks.R;

public class OrderNowAdapter extends RecyclerView.Adapter<OrderNowAdapter.OrderNowViewHolder> {

    Context contextOrderNow;
    List<Product> listIteamProduct;

    public static List<Product> addToCardArrayIteam;

    SharedPreferences sharedPreferences;

    public OrderNowAdapter(Context contextOrderNow, List<Product> listIteamProduct) {
        this.contextOrderNow = contextOrderNow;
        this.listIteamProduct = listIteamProduct;
    }

    @NonNull
    @Override
    public OrderNowViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.rcv_order_now,parent,false);
        return new OrderNowViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderNowViewHolder holder, final int position) {

//        holder.productID.setText(listIteamProduct.get(position).getProductID());
        holder.productName.setText(listIteamProduct.get(position).getProductName());
        holder.productPrice.setText(listIteamProduct.get(position).getProductPrice());
        holder.productQuantity.setText(listIteamProduct.get(position).getProductQuantity());

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(contextOrderNow, listIteamProduct.get(position).getProductName(), Toast.LENGTH_SHORT).show();
            }
        });

        holder.btnAddtoCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Toast.makeText(contextOrderNow, "you added item in card", Toast.LENGTH_SHORT).show();
                    if (addToCardArrayIteam.contains(listIteamProduct.get(position))){
                        Toast.makeText(contextOrderNow, "this iteam is already in card", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        addToCardArrayIteam.add(listIteamProduct.get(position));

                       // Toast.makeText(contextOrderNow, addToCardArrayIteam.toString(), Toast.LENGTH_SHORT).show();
                        try{
                            sharedPreferences=contextOrderNow.getSharedPreferences("SP",Context.MODE_PRIVATE);
                            Gson gson=new Gson();
                            String json=gson.toJson(addToCardArrayIteam);
                            SharedPreferences.Editor editor=sharedPreferences.edit();
                            editor.putString("card_List_Product_From_SP",json);
                            editor.commit();
                        }catch (Exception e){
                            Toast.makeText(contextOrderNow, "catch error in doing shared prefrencre=="+e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }

                } catch (Exception e) {
                    Log.e("error", e.toString());
                    Toast.makeText(contextOrderNow, "catch run  on model adapter==" + e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return listIteamProduct.size() ;
    }

    public class OrderNowViewHolder extends RecyclerView.ViewHolder{
        TextView productID,productName,productPrice,productQuantity;
        LinearLayout linearLayout;
        Button btnAddtoCard;

        public OrderNowViewHolder(@NonNull View itemView) {
            super(itemView);

          //  productID=itemView.findViewById(R.id.tvRId);
            productName=itemView.findViewById(R.id.tvRName);
            productPrice=itemView.findViewById(R.id.tvRPrice);
            productQuantity=itemView.findViewById(R.id.tvRQuantity);
            linearLayout=itemView.findViewById(R.id.ll);
            btnAddtoCard=itemView.findViewById(R.id.btnAddtoCard);

            addToCardArrayIteam=new ArrayList<>();

            //SharedPreferences sharedPreferences=itemView.getContext().getSharedPreferences("SP",Context.MODE_PRIVATE);

        }
    }
}
