package ZanwarTech.minor2.team3.HungryChunks.Classes;

import java.io.Serializable;

public class Payment implements Serializable {
    String paymentID,orderId,customerId,paymentMode,paidAmount;

    public Payment(String paymentID, String orderId, String customerId, String paymentMode, String paidAmount) {
        this.paymentID = paymentID;
        this.orderId = orderId;
        this.customerId = customerId;
        this.paymentMode = paymentMode;
        this.paidAmount = paidAmount;
    }

    public String getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(String paymentID) {
        this.paymentID = paymentID;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(String paidAmount) {
        this.paidAmount = paidAmount;
    }
}
