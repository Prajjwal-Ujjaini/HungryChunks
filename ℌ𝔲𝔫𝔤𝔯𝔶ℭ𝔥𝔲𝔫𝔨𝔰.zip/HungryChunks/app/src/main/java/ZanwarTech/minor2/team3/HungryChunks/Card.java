package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import ZanwarTech.minor2.team3.HungryChunks.Adapters.CardAdapter;
import ZanwarTech.minor2.team3.HungryChunks.Classes.Product;

public class Card extends AppCompatActivity {

    RecyclerView recyclerViewCart;
    List<Product> productListCart;//used for to show list of product
    CardAdapter cardAdapterToShowRcv; //adapter of rcv

//    CardAdapter cardAdapterToCalculateAmount;//object of adapter to calculate amount

    List<Product> cardListProductFromSP; //taking list of product from card from SP
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);
        getSupportActionBar().setTitle("Card");

        recyclerViewCart=findViewById(R.id.rcvCart);

        sharedPreferences=getSharedPreferences("SP",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();

        recyclerViewCart.setHasFixedSize(true);
        recyclerViewCart.setLayoutManager(new LinearLayoutManager(this));
        DividerItemDecoration dividerItemDecoration=new DividerItemDecoration(this,DividerItemDecoration.VERTICAL);
        recyclerViewCart.addItemDecoration(dividerItemDecoration);

        productListCart=new ArrayList<>(); //initilizing product list for showing
        cardListProductFromSP=new ArrayList<>();//initilizing list of product in card  for geting

        getCardProductListFromSP();//calling of function for retriving card list product from sp

        cardAdapterToShowRcv= new CardAdapter(this,productListCart);
        recyclerViewCart.setAdapter(cardAdapterToShowRcv);

        editor.putString("Product_List_cart_size", String.valueOf(productListCart.size()));
        editor.commit();

    }

   public void getCardProductListFromSP(){
       //by shared preference
       try {
           Gson gson=new Gson(); //get
           String json=sharedPreferences.getString("card_List_Product_From_SP","DEFAULT card_List_Product_From_SP");
           if (json.isEmpty()){
               Toast.makeText(this, "There is nothing", Toast.LENGTH_SHORT).show();
           }else {
               Type type=new TypeToken<List<Product>>(){}.getType();
               cardListProductFromSP=gson.fromJson(json,type);

               try{
                   if(cardListProductFromSP.isEmpty()){
                       Toast.makeText(this, "your card is empty please add iteam", Toast.LENGTH_SHORT).show();
                   }
                   else {
                       for(int i=0;i<cardListProductFromSP.size();i++){
                           productListCart.add(cardListProductFromSP.get(i));
                          // Toast.makeText(getApplicationContext(), productListCart.get(i).getProductName(), Toast.LENGTH_SHORT).show();
                       }
                   }
               }catch (Exception e){
                   Toast.makeText(this, "error inside try of try n catch in else=**=="+e.toString(), Toast.LENGTH_SHORT).show();
               }
           }
       }catch (Exception e){
           Toast.makeText(this, "shared p==="+e.toString(), Toast.LENGTH_SHORT).show();
       }
        /*
        //by direct calling of array from adapter class
        try{
            if(OrderNowAdapter.addToCardArrayIteam.isEmpty()){
                Toast.makeText(this, "your card is empty please add iteam", Toast.LENGTH_SHORT).show();
            }
            else {
                for(int i=0;i<OrderNowAdapter.addToCardArrayIteam.size();i++){

                    productListCart.add(OrderNowAdapter.addToCardArrayIteam.get(i));
                }
            }
        }catch (Exception e){
            Log.e("error", e.toString());
            Toast.makeText(this, "catch in cart in getIncoming Intent=="+e.toString(), Toast.LENGTH_SHORT).show();
        }

   */

   }

   public void gotoTryConfirmBox(View view) {
        Intent intent = new Intent(this, ConfirmPage.class);
        startActivity(intent);
    }
}
