package ZanwarTech.minor2.team3.HungryChunks.Classes;

import java.io.Serializable;

public class Order implements Serializable {
   private String orderID,productID,customerID,orderDate,orderQuantity;

    public Order(String orderID, String productID, String customerID, String orderDate, String orderQuantity) {
        this.orderID = orderID;
        this.productID = productID;
        this.customerID = customerID;
        this.orderDate = orderDate;
        this.orderQuantity = orderQuantity;
    }

    public Order(String productID, String customerID, String orderDate, String orderQuantity) {
        this.productID = productID;
        this.customerID = customerID;
        this.orderDate = orderDate;
        this.orderQuantity = orderQuantity;
    }

    public Order(String productID, String orderDate, String orderQuantity) {
        this.productID = productID;
        this.orderDate = orderDate;
        this.orderQuantity = orderQuantity;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderQuantity() {
        return orderQuantity;
    }

    public void setOrderQuantity(String orderQuantity) {
        this.orderQuantity = orderQuantity;
    }
}
