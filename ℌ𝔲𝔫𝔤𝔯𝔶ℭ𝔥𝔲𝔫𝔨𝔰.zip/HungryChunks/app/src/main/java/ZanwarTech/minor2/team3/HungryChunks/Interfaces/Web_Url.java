package ZanwarTech.minor2.team3.HungryChunks.Interfaces;

public interface Web_Url {
    String Url="https://zanwar.000webhostapp.com/student_web/";
}
