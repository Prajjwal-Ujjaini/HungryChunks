package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import ZanwarTech.minor2.team3.HungryChunks.Interfaces.Web_Url;

public class CustomerRegistration extends AppCompatActivity implements Web_Url {
    private EditText etSignupName,etSignupMno,etSignupPwd;
    private String strSignupName,strSignupMno,strSignupPwd;
    ProgressBar pbCR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_registration);
        getSupportActionBar().setTitle("Customer Registration");

        macthId();

       /* bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCustomer(v);
            }
        });
       */
    }

    /*public void gotoV(View view){
        Intent intent=new Intent(this,Verification.class);
        startActivity(intent);
    }
    */

    public void gotoS(View view) {
        Intent intent = new Intent(this, LoginCustomer.class);
        Toast.makeText(this, "by function intent", Toast.LENGTH_SHORT).show();
        startActivity(intent);
    }

    public void macthId(){    //function for matching id
        etSignupName=findViewById(R.id.etCAName);
        //etSignupMno=findViewById(R.id.etCAMno);
        etSignupPwd=findViewById(R.id.etCAPwd);

        pbCR=findViewById(R.id.pbCR);

        strSignupMno=getIntent().getStringExtra("mno");
        Toast.makeText(this, strSignupMno, Toast.LENGTH_SHORT).show();
        //bt=findViewById(R.id.bttry);
    }

    public void addCustomer(View view){
        strSignupName=etSignupName.getText().toString().trim();
        //strSignupMno=etSignupMno.getText().toString().trim();
        strSignupMno=getIntent().getStringExtra("mno");

        strSignupPwd=etSignupPwd.getText().toString().trim();
        if (strSignupMno.length() < 10) {
            Toast.makeText(getApplicationContext(), "Please Enter 10 digit mobile number", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(strSignupPwd)){
            Toast.makeText(getApplicationContext(), "Please enter password", Toast.LENGTH_SHORT).show();
            return;
        }
        if (strSignupPwd.length() < 6) {
            Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!TextUtils.isEmpty(strSignupName) && !TextUtils.isEmpty(strSignupMno) && !TextUtils.isEmpty(strSignupPwd))
        {
            pbCR.setVisibility(View.VISIBLE);

            final Map map=new HashMap();
            map.put("cstmr_name",strSignupName );
            map.put("cstmr_mno",strSignupMno );
            map.put("cstmr_pwd",strSignupPwd );

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            //Toast.makeText(this, "after request", Toast.LENGTH_SHORT).show();
            //Toast.makeText(this, strSignupName, Toast.LENGTH_SHORT).show();
            //Toast.makeText(this, strSignupMno, Toast.LENGTH_SHORT).show();
            //Toast.makeText(this, strSignupPwd, Toast.LENGTH_SHORT).show();
            StringRequest stringRequest=new StringRequest(Request.Method.POST, Url + "add_Customer.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonObject=new JSONObject(response);
                        String data=jsonObject.getString("success");

                        //Toast.makeText(getApplicationContext(), "data ="+data, Toast.LENGTH_SHORT).show();
                        //Toast.makeText(getApplicationContext(), "in try after json  ", Toast.LENGTH_SHORT).show();

                        if(data.equals("1")){
                          //  Toast.makeText(getApplicationContext(), "this is running equals 1", Toast.LENGTH_SHORT).show();
                           //Proreass bar show
                            Intent intent=new Intent(getApplicationContext(),LoginCustomer.class);
                            Toast.makeText(getApplicationContext(), "Regristration success full !! Please login with your cradentials!!", Toast.LENGTH_SHORT).show();
                            pbCR.setVisibility(View.GONE);

                          try{
                                SharedPreferences spCustomerRegristration=getSharedPreferences("SP",MODE_PRIVATE);
                                SharedPreferences.Editor editorCR=spCustomerRegristration.edit();
                                editorCR.putString("CustomerName",strSignupName);
                                editorCR.putString("CustomerMno",strSignupMno);
                                editorCR.commit();
                            }catch (Exception e){
                                Toast.makeText(CustomerRegistration.this, "catch in shared P=="+e.toString(), Toast.LENGTH_SHORT).show();
                             }

                            startActivity(intent);
                        }else{
                            pbCR.setVisibility(View.GONE);
                            Toast.makeText(getApplicationContext(), "Not Regristered", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e("catch error:", e.toString());
                        pbCR.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(), /*"catch run ==="+*/ e.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("error", error.toString());
                    pbCR.setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(), " error listnor run :==="+ error.toString(), Toast.LENGTH_SHORT).show();
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    return map;
                }
            };
            requestQueue.add(stringRequest);

            etSignupName.setText("");
//            etSignupMno.setText("");
            etSignupPwd.setText("");
        } else {
            pbCR.setVisibility(View.GONE);
            Toast.makeText(this, "Please enter data first", Toast.LENGTH_SHORT).show();
        }
    }
}
