package ZanwarTech.minor2.team3.HungryChunks;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ZanwarTech.minor2.team3.HungryChunks.Adapters.ConfirmAdapter;
import ZanwarTech.minor2.team3.HungryChunks.Classes.Product;
import ZanwarTech.minor2.team3.HungryChunks.Interfaces.Web_Url;

public class ConfirmPage extends AppCompatActivity implements Web_Url {

    RecyclerView rcvTryConfirm;
    List<Product> amountList;
    ConfirmAdapter confirmAdapter;

    TextView txtTotalAmount; //to display final amount in txtView

    static int TotalFinalAmount;//total final Amount

    SimpleDateFormat simpleDateFormat;
    String CurrentDate,CustomerID;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    ProgressBar pbCp;
    Button btnPlacedOrder;
    // List<Order> confirmOrderList;//used for to take final list of card product


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_page);
        getSupportActionBar().setTitle("Confirm Page");

        txtTotalAmount=findViewById(R.id.txtCpTotalAmount);
        rcvTryConfirm=findViewById(R.id.rcvConfirmPage);
        pbCp=findViewById(R.id.pbCp);
        btnPlacedOrder=findViewById(R.id.btnPlacedOrder);

        rcvTryConfirm.setHasFixedSize(true);
        rcvTryConfirm.setLayoutManager(new LinearLayoutManager(this));
        DividerItemDecoration dividerItemDecoration=new DividerItemDecoration(this,DividerItemDecoration.VERTICAL);
        rcvTryConfirm.addItemDecoration(dividerItemDecoration);

        simpleDateFormat=new SimpleDateFormat("dd.MM.yyyy");
        CurrentDate=simpleDateFormat.format(new Date());

        sharedPreferences=getSharedPreferences("SP",MODE_PRIVATE);
        editor=sharedPreferences.edit();

        amountList=new ArrayList<>();
        //   confirmOrderList=new ArrayList<>();//initilizing final order list

        getFromSharedP();
        CalcutateFinalAmount();

        txtTotalAmount.setText("Total Amount to Pay="+TotalFinalAmount);

        confirmAdapter = new ConfirmAdapter(this,amountList);
        rcvTryConfirm.setAdapter(confirmAdapter);

        btnPlacedOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadOrder();
                uploadDataToSharedP();
            }
        });


           /*
        //add confirm order list to shared prefrence
        Gson gsonConfirmOL=new Gson(); //put
        String jsonConfirmOL=gsonConfirmOL.toJson(confirmOrderList);
        editor.putString("Confirm_Order_List",jsonConfirmOL);

        editor.commit();
         */

    }


    public void getFromSharedP(){
        Gson gsonCtry=new Gson();
        String jsonCtry=sharedPreferences.getString("amount_Added_List","DEFAULT amount_Added_List");
        if (jsonCtry.isEmpty()){
            Toast.makeText(this, "There is nothing", Toast.LENGTH_SHORT).show();
        }else {
            Type type = new TypeToken<List<Product>>() {}.getType();
            amountList= gsonCtry.fromJson(jsonCtry, type);
        }
        //Toast.makeText(this, ifWorkd.toString(), Toast.LENGTH_SHORT).show();

        CustomerID=sharedPreferences.getString("CustomerId", "DEFAULT Customer Id");
    }

    public void uploadDataToSharedP(){

        editor.putString("FinalTotalAmount", String.valueOf(TotalFinalAmount));//for payment table
        editor.putString("OrderDate",CurrentDate);//for order table
        editor.commit();
     //   Toast.makeText(this, "final anount"+TotalFinalAmount, Toast.LENGTH_SHORT).show();
    }

    public void CalcutateFinalAmount(){
        getFromSharedP();
        TotalFinalAmount=0;

        //String listSize=sharedPreferences.getString("Product_List_cart_size","DEFAULT Product_List_cart_size" );

        for (int i=0;i<amountList.size();i++){

            String tmp=amountList.get(i).getAmountToPay();

            int tmpPositionOfProductList =0 ;
            tmpPositionOfProductList =Integer.parseInt(tmp);

            TotalFinalAmount= TotalFinalAmount + tmpPositionOfProductList ;
        }

/*        for (int i=0;i<cardListProductFromSP.size();i++){
            try{
                Order order=new Order(cardListProductFromSP.get(i).getProductID(),CurrentDate,productListCart.get(i).getTmpOrderQuantity());
                confirmOrderList.add(order);
            }catch (Exception e){
                Toast.makeText(this, "catch order=="+e.toString(), Toast.LENGTH_SHORT).show();
            }
        }
 */
    }

    public void gotoPay(View view) {
        Intent intent=new Intent(this,PaymentPage.class);
        startActivity(intent);
    }

    public void uploadOrder(){

        for(int i=0;i<amountList.size();i++){
            pbCp.setVisibility(View.VISIBLE);
            final Map map=new HashMap();
            map.put("p_id",amountList.get(i).getProductID());
            map.put("c_id",CustomerID);
            map.put("o_date",CurrentDate);
            map.put("o_quantity",amountList.get(i).getTmpOrderQuantity());

            RequestQueue requestQueueConfirmPage = Volley.newRequestQueue(this);
            final int finalI = i;
            StringRequest stringRequestConfirmPage=new StringRequest(Request.Method.POST, Url+"upload_OrderHistory.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                  //  Toast.makeText(ConfirmPage.this, response, Toast.LENGTH_SHORT).show();
                    try {
                        JSONObject jsonObjectConfirmPage=new JSONObject(response);
                    //    Toast.makeText(ConfirmPage.this, jsonObjectConfirmPage.toString(), Toast.LENGTH_SHORT).show();
                        String data=jsonObjectConfirmPage.getString("success");
                      //  Toast.makeText(ConfirmPage.this, "data on confirm page="+data, Toast.LENGTH_SHORT).show();

                        if(data.equals("1")){
                            Toast.makeText(ConfirmPage.this, "ORDER PLACED pleas procide for Payment", Toast.LENGTH_SHORT).show();
                            pbCp.setVisibility(View.GONE);
                        }else {
                            pbCp.setVisibility(View.GONE);
                            Toast.makeText(getApplicationContext(), "Order not placed"+ amountList.get(finalI).getProductID(), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e("catch error:", e.toString());
                        pbCp.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(), "catch run ==="+ e.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("error", error.toString());
                    pbCp.setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(), " error listnor run  on Confirm page:==="+ error.toString(), Toast.LENGTH_SHORT).show();
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    return map;
                }
            };
            requestQueueConfirmPage.add(stringRequestConfirmPage);
        }

    }
}
