package ZanwarTech.minor2.team3.HungryChunks.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import ZanwarTech.minor2.team3.HungryChunks.Classes.Product;
import ZanwarTech.minor2.team3.HungryChunks.R;

public class ConfirmAdapter extends RecyclerView.Adapter<ConfirmAdapter.TryViewHolder> {
    Context contextConfirm;
    List<Product> listItemTry;

    public ConfirmAdapter(Context contextConfirm, List<Product> listItemTry) {
        this.contextConfirm = contextConfirm;
        this.listItemTry = listItemTry;
    }

    @NonNull
    @Override
    public TryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.rcv_try_confirm_box,parent,false);
        return new ConfirmAdapter.TryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TryViewHolder holder, int position) {

        holder.productID.setText(listItemTry.get(position).getProductName());
        holder.productQuantity.setText(listItemTry.get(position).getTmpOrderQuantity());
        holder.amountToPay.setText(listItemTry.get(position).getAmountToPay());
    }

    @Override
    public int getItemCount() {
        return listItemTry.size();
    }

    public class TryViewHolder extends RecyclerView.ViewHolder {
        TextView productID,productQuantity,amountToPay;

        public TryViewHolder(@NonNull View itemView) {
            super(itemView);

            productID=itemView.findViewById(R.id.txtTryId);
            productQuantity=itemView.findViewById(R.id.txtTryQuantity);
            amountToPay=itemView.findViewById(R.id.txtTryAmountToPay);
        }
    }
}
