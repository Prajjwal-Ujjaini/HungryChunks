package ZanwarTech.minor2.team3.HungryChunks.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import ZanwarTech.minor2.team3.HungryChunks.Classes.Payment;
import ZanwarTech.minor2.team3.HungryChunks.R;

public class PaymentAdapter extends RecyclerView.Adapter<PaymentAdapter.PaymentViewHolder> {

    Context contextPayment;
    List<Payment> paymentListHistory;

    public PaymentAdapter(Context contextPayment, List<Payment> paymentListHistory) {
        this.contextPayment = contextPayment;
        this.paymentListHistory = paymentListHistory;
    }

    @NonNull
    @Override
    public PaymentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.rcv_payment_history,parent,false);
        return new PaymentViewHolder(view);
    }
  @Override
    public void onBindViewHolder(@NonNull PaymentViewHolder holder, int position) {

        holder.paymentID.setText("PaymentId="+paymentListHistory.get(position).getPaymentID());
       // holder.orderId.setText(paymentListHistory.get(position).getOrderId());
       // holder.customerId.setText(paymentListHistory.get(position).getCustomerId());
        holder.paymentMode.setText("Payment Mode="+paymentListHistory.get(position).getPaymentMode());
        holder.paidAmount.setText("Paid Amount="+paymentListHistory.get(position).getPaidAmount());

    }

   @Override
    public int getItemCount() {
        return paymentListHistory.size();
    }

    public class PaymentViewHolder extends RecyclerView.ViewHolder {
        TextView paymentID,orderId,customerId,paymentMode,paidAmount;

        public PaymentViewHolder(@NonNull View itemView) {
            super(itemView);

            paymentID=itemView.findViewById(R.id.txtPyHisPaymenId);
         //   orderId=itemView.findViewById(R.id.txtPyHisOrderID);
         //   customerId=itemView.findViewById(R.id.txtPyHisCustomerId);
            paymentMode=itemView.findViewById(R.id.txtPyHisPaymentMode);
            paidAmount=itemView.findViewById(R.id.txtPyHisPaidAmount);
        }
    }
}
